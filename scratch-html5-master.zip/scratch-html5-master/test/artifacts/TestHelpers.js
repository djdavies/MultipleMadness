'use strict';

var deepCopy = function(object) {
 return jQuery.extend(true, {}, object);
}
