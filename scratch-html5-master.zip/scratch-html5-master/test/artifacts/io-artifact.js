'use strict';

var io_base = 'proxy.php?resource=internalapi/';
var project_base = 'http://cdn.projects.scratch.mit.edu/internalapi/project/';
var project_suffix = '/get/';
var asset_base = 'http://cdn.assets.scratch.mit.edu/internalapi/asset/';
var asset_suffix = '/get/';
var soundbank_base = 'soundbank/';
var spriteLayerCount = 0;
