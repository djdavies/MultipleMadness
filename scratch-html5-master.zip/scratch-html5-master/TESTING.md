To set up the player for testing and development, simply download the source and open [index.html](https://github.com/LLK/scratch-html5/blob/master/index.html) in a recent web browser (Chrome, Firefox, Safari and other Webkit/Gecko-based browsers work best).  You can also compare performance and features to the production Flash player by opening [compare.html](https://github.com/LLK/scratch-html5/blob/master/compare.html).

The Scratch HTML5 player is no longer dependent on a local proxy.
